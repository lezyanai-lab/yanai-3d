export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: { fontFamily: { sans: ["Heebo", "sans-serif"] } },
  },
  plugins: [],
};
